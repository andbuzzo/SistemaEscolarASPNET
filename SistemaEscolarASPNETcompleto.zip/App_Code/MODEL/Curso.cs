﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisEscolar.App_Code.MODEL
{
    public class Curso
    {
        public int codigo { get; set; }
        public string descricao { get; set; }
        public int professor { get; set; }
    }
}